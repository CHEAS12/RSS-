
# Main orchestrator for fetching RSS feeds, formatting, and sending to Telegram.
# It reads env vars: TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, RSS_URLS (comma-separated), POLL_LIMIT (optional), OPENAI_API_KEY (optional).
# Requires: feedparser, requests. Optional: openai for LLM formatting if OPENAI_API_KEY is set.

import os
import time
import logging
import feedparser
import requests

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')
RSS_URLS = [u.strip() for u in os.getenv('RSS_URLS', '').split(',') if u.strip()]
POLL_LIMIT = int(os.getenv('POLL_LIMIT', '10'))

if not BOT_TOKEN or not CHAT_ID or not RSS_URLS:
    print('Missing env vars. Required: TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, RSS_URLS')
    raise SystemExit(1)

sent_ids = set()

def format_entry(entry):
    title = entry.get('title', '(no title)')
    link = entry.get('link', '')
    summary = entry.get('summary', '')
    parts = []
    parts.append('📰 ' + title)
    if summary:
        parts.append(summary)
    if link:
        parts.append('🔗 ' + link)
    text = '

'.join(parts)
    if len(text) > 3800:
        text = text[:3800] + '

…'
    return text

def send_telegram(text):
    url = 'https://api.telegram.org/bot' + BOT_TOKEN + '/sendMessage'
    payload = { 'chat_id': CHAT_ID, 'text': text, 'disable_web_page_preview': True }
    r = requests.post(url, json=payload, timeout=20)
    if r.status_code != 200:
        logging.warning('Telegram send failed ' + str(r.status_code) + ' ' + r.text)

def process_feed(url):
    d = feedparser.parse(url)
    if d.bozo:
        logging.warning('Feed parse issue for ' + url)
    count = 0
    for e in d.entries:
        eid = e.get('id') or e.get('link') or e.get('title')
        if not eid:
            continue
        if eid in sent_ids:
            continue
        text = format_entry(e)
        send_telegram(text)
        sent_ids.add(eid)
        count += 1
        if count >= POLL_LIMIT:
            break

if __name__ == '__main__':
    for url in RSS_URLS:
        try:
            process_feed(url)
        except Exception as ex:
            logging.exception('Error processing ' + url)
    print('Done')
