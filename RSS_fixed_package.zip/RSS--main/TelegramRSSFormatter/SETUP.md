# Инструкция по настройке Telegram RSS бота

## Быстрый старт

### 1. Получение необходимых ключей

#### OpenAI API Key
1. Перейдите на https://platform.openai.com
2. Зарегистрируйтесь или войдите в аккаунт
3. Перейдите в раздел API Keys: https://platform.openai.com/api-keys
4. Нажмите "Create new secret key"
5. Скопируйте ключ (он показывается только один раз!)
6. Убедитесь, что у вас есть кредиты на балансе для использования GPT-5

#### Telegram Bot Token
1. Откройте Telegram
2. Найдите бота @BotFather
3. Отправьте команду `/newbot`
4. Следуйте инструкциям:
   - Введите имя для бота (например: "My RSS Bot")
   - Введите username для бота (должен заканчиваться на "bot", например: "my_rss_bot")
5. Получите токен вида: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`
6. Сохраните этот токен

### 2. Настройка в Replit

Ключи уже добавлены в Replit Secrets:
- ✅ `OPENAI_API_KEY`
- ✅ `TELEGRAM_BOT_TOKEN`

### 3. Настройка RSS фидов

Отредактируйте файл `config.json`:

```json
{
  "telegram_bot_token": "",
  "openai_api_key": "",
  "default_check_interval": 300,
  "feeds": [
    {
      "url": "https://example.com/feed.xml",
      "name": "Мой фид",
      "chat_ids": ["@my_channel", "123456789"],
      "check_interval": 300,
      "enable_emojis": true,
      "custom_hashtags": ["RSS", "Новости"],
      "enable_link_preview": true,
      "enable_media": true,
      "show_author": true,
      "ai_enhance": true
    }
  ]
}
```

**Важно:**
- Оставьте `telegram_bot_token` и `openai_api_key` пустыми - они берутся из Secrets
- В `chat_ids` укажите:
  - Для каналов: `@channel_username` (бот должен быть админом канала)
  - Для личных чатов: числовой ID (получите через @userinfobot)

### 4. Получение Chat ID

#### Для канала:
1. Добавьте бота в канал как администратора
2. Используйте username канала: `@your_channel`

#### Для личного чата:
1. Найдите бота @userinfobot в Telegram
2. Отправьте ему любое сообщение
3. Скопируйте ваш ID (числовое значение)
4. Используйте это число в `chat_ids`

### 5. Запуск

Бот запускается автоматически через workflow "RSS Bot". Вы можете:
- Посмотреть логи в консоли
- Остановить/запустить через панель workflows
- Отредактировать `config.json` для изменения настроек

## Параметры конфигурации

### Глобальные настройки

- `telegram_bot_token`: Токен Telegram бота (оставьте пустым)
- `openai_api_key`: Ключ OpenAI API (оставьте пустым)
- `default_check_interval`: Интервал проверки по умолчанию (секунды)

### Настройки фида

- `url`: URL RSS/Atom фида (обязательно)
- `name`: Название фида (обязательно)
- `chat_ids`: Список ID чатов/каналов (обязательно)
- `check_interval`: Интервал проверки фида в секундах (по умолчанию: 300)
- `enable_emojis`: Добавлять эмодзи в заголовок (по умолчанию: false)
- `custom_hashtags`: Список хэштегов для добавления к постам
- `enable_link_preview`: Показывать превью ссылок в Telegram (по умолчанию: true)
- `enable_media`: Отправлять медиа вложения из RSS (по умолчанию: true)
- `show_author`: Показывать автора поста (по умолчанию: true)
- `ai_enhance`: Использовать AI для улучшения форматирования (по умолчанию: true)

## Популярные RSS фиды

### Технологии
- NY Times Tech: `https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml`
- Hacker News: `https://news.ycombinator.com/rss`
- TechCrunch: `https://techcrunch.com/feed/`

### Новости
- BBC News: `http://feeds.bbci.co.uk/news/rss.xml`
- Reuters: `https://www.reutersagency.com/feed/`

### Разработка
- GitHub Blog: `https://github.blog/feed/`
- Dev.to: `https://dev.to/feed`

## Устранение неполадок

### Бот не отправляет сообщения

1. Проверьте, что бот добавлен в канал как администратор
2. Убедитесь, что `chat_ids` указаны правильно
3. Проверьте логи на наличие ошибок

### AI-генерация не работает

1. Проверьте баланс OpenAI API
2. Убедитесь, что `OPENAI_API_KEY` настроен правильно
3. Бот автоматически переключится на простое форматирование при ошибках AI

### Фиды не обновляются

1. Проверьте, что URL фида корректный и доступен
2. Увеличьте `check_interval` если фид обновляется редко
3. Проверьте логи на ошибки парсинга

## Формат RSStT

Бот форматирует сообщения по стандарту RSStT:

```
**Заголовок поста** 📰

#хэштег1 #хэштег2

Содержание поста, отформатированное AI для лучшей читаемости...

_Автор: Имя Автора_

[Название Фида](https://ссылка-на-пост)
```

## Пример полной конфигурации

```json
{
  "telegram_bot_token": "",
  "openai_api_key": "",
  "default_check_interval": 300,
  "feeds": [
    {
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml",
      "name": "NY Times Tech",
      "chat_ids": ["@tech_news_channel"],
      "check_interval": 600,
      "enable_emojis": true,
      "custom_hashtags": ["Tech", "NYT"],
      "enable_link_preview": true,
      "enable_media": true,
      "show_author": false,
      "ai_enhance": true
    },
    {
      "url": "https://github.blog/feed/",
      "name": "GitHub Blog",
      "chat_ids": ["@dev_channel", "123456789"],
      "check_interval": 900,
      "enable_emojis": false,
      "custom_hashtags": ["GitHub", "Dev"],
      "enable_link_preview": false,
      "enable_media": true,
      "show_author": true,
      "ai_enhance": true
    }
  ]
}
```
