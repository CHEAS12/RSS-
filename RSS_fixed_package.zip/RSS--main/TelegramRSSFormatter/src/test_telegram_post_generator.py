#!/usr/bin/env python3
"""
Тест функции генерации постов для Telegram с использованием OpenAI API
"""

import os
import sys
import logging
from typing import Dict, Any

# Добавляем путь к src для импорта модулей
sys.path.append(os.path.join(os.path.dirname(__file__)))

from rss_formatter import RSSFormatter, RSSPost

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def create_test_news_item() -> RSSPost:
    """
    Создает тестовый объект новости для демонстрации работы генератора постов.
    """
    return RSSPost(
        title="Прорыв в области искусственного интеллекта: новый алгоритм превосходит GPT-4",
        author="Дмитрий Иванов",
        summary="""Исследователи из Стэнфордского университета представили революционную 
        архитектуру нейронной сети, которая показывает результаты на 30% лучше GPT-4 
        в задачах понимания естественного языка. Новая модель использует принципиально 
        иной подход к обработке контекста и может работать с текстами длиной до 2 
        миллионов токенов при значительно меньших вычислительных затратах. 

        Ключевые особенности:
        • Улучшенное понимание контекста
        • Снижение вычислительных затрат на 40%
        • Поддержка мультимодального ввода
        • Открытый исходный код для исследовательского сообщества

        Авторы планируют опубликовать полные результаты исследования в журнале 
        Nature Machine Intelligence в следующем месяце.""",
        link="https://example-news.com/ai-breakthrough-2024",
        feed_title="TechNews Daily",
        content="""В мире искусственного интеллекта произошел значительный прорыв. 
        Команда исследователей под руководством профессора Алексиса Коннолли из 
        Стэнфордского университета разработала новую архитектуру трансформера, 
        получившую название 'Quantum-Attention Transformer' (QAT).

        Экспериментальные результаты показали, что QAT превосходит GPT-4 на:
        - 31% в задачах суммаризации текста
        - 28% в задачах перевода
        - 35% в логических рассуждениях
        - 42% в задачах программирования

        Особенно впечатляет способность модели работать с длинными контекстами. 
        Если GPT-4 эффективно обрабатывает до 128k токенов, то QAT может работать 
        с контекстами до 2M токенов без значительной потери качества.

        'Мы смогли преодолеть фундаментальные ограничения традиционной архитектуры 
        attention, применив принципы квантовых вычислений к механизму внимания', - 
        комментирует профессор Коннолли.

        Исходный код модели будет опубликован под лицензией MIT для стимулирования 
        дальнейших исследований в области ИИ.""",
        media_attachments=[
            {
                "url": "https://example-news.com/images/ai-breakthrough.jpg",
                "type": "image/jpeg"
            }
        ]
    )

def test_ai_post_generation():
    """
    Тестирует функцию generate_telegram_post() с примером новости.
    """
    logger.info("🚀 Запуск теста генерации постов для Telegram")

    try:
        # Проверяем наличие API ключа
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            logger.error("❌ OPENAI_API_KEY не найден в переменных окружения")
            logger.info("💡 Установите ключ: export OPENAI_API_KEY='your-key-here'")
            return

        logger.info(f"✅ OpenAI API ключ найден (длина: {len(api_key)} символов)")

        # Создаем форматтер с AI-генерацией
        formatter = RSSFormatter(
            openai_api_key=api_key,
            enable_emojis=True,
            ai_enhance=True,
            length_limit=1024,
            enable_link_preview=True,
            enable_media=True
        )

        logger.info("✅ RSSFormatter инициализирован успешно")

        # Создаем тестовый объект новости
        test_news = create_test_news_item()
        logger.info(f"✅ Тестовая новость создана: '{test_news.title[:50]}...'")

        print("\n" + "="*80)
        print("📰 ТЕСТОВАЯ НОВОСТЬ (ВХОД)")
        print("="*80)
        print(f"📌 ЗАГОЛОВОК: {test_news.title}")
        print(f"✍️ АВТОР: {test_news.author}")
        print(f"📡 ИСТОЧНИК: {test_news.feed_title}")
        print(f"🔗 ССЫЛКА: {test_news.link}")
        print(f"📝 КРАТКОЕ ОПИСАНИЕ: {test_news.summary[:200]}...")
        print(f"🖼️ МЕДИА: {len(test_news.media_attachments)} вложений")

        # Генерируем пост с помощью AI
        logger.info("🤖 Запуск AI-генерации поста...")
        generated_post = formatter.generate_telegram_post(test_news)

        print("\n" + "="*80)
        print("🤖 СГЕНЕРИРОВАННЫЙ ПОСТ ДЛЯ TELEGRAM (ВЫХОД)")
        print("="*80)
        print(generated_post["text"])

        print("\n" + "-"*80)
        print("📊 МЕТАДАННЫЕ ПОСТА")
        print("-"*80)
        print(f"📏 Длина текста: {len(generated_post['text'])} символов")
        print(f"🖼️ Медиа вложений: {len(generated_post.get('media', []))}")
        print(f"🔗 Превью ссылки: {'Да' if generated_post.get('link_preview') else 'Нет'}")

        if generated_post.get('media'):
            print("\n📎 МЕДИА ВЛОЖЕНИЯ:")
            for i, media in enumerate(generated_post['media'], 1):
                print(f"  {i}. {media.get('type', 'unknown')} - {media.get('url', 'no url')}")

        print("\n" + "="*80)
        print("✅ ТЕСТ ЗАВЕРШЕН УСПЕШНО!")
        print("="*80)

        logger.info("🎉 Тест AI-генерации постов завершен успешно")
        return generated_post

    except Exception as e:
        logger.error(f"❌ Ошибка при тестировании: {e}")
        print(f"\n❌ ОШИБКА: {e}")
        return None

def test_fallback_formatting():
    """
    Тестирует базовое форматирование без AI (fallback режим).
    """
    logger.info("🔄 Запуск теста базового форматирования (без AI)")

    try:
        # Создаем форматтер БЕЗ AI-генерации
        formatter = RSSFormatter(
            openai_api_key="fake-key",  # Используем фальшивый ключ для теста
            ai_enhance=False,  # Отключаем AI
            enable_emojis=True,
            length_limit=1024
        )

        test_news = create_test_news_item()
        formatted_post = formatter.format_post(test_news)

        print("\n" + "="*80)
        print("📝 БАЗОВОЕ ФОРМАТИРОВАНИЕ (БЕЗ AI)")
        print("="*80)
        print(formatted_post["text"])
        print(f"\n📏 Длина: {len(formatted_post['text'])} символов")

        logger.info("✅ Тест базового форматирования успешен")
        return formatted_post

    except Exception as e:
        logger.error(f"❌ Ошибка в базовом форматировании: {e}")
        return None

def compare_formats():
    """
    Сравнивает AI-генерацию с базовым форматированием.
    """
    print("\n" + "="*80)
    print("⚖️ СРАВНЕНИЕ МЕТОДОВ ФОРМАТИРОВАНИЯ")
    print("="*80)

    # Тест с AI
    ai_result = test_ai_post_generation()

    print("\n" + "-"*40)

    # Тест без AI
    fallback_result = test_fallback_formatting()

    if ai_result and fallback_result:
        print("\n📈 СТАТИСТИКА СРАВНЕНИЯ:")
        print(f"  AI пост: {len(ai_result['text'])} символов")
        print(f"  Базовый пост: {len(fallback_result['text'])} символов")
        print(f"  Разница: {len(ai_result['text']) - len(fallback_result['text'])} символов")

if __name__ == "__main__":
    print("🎯 ТЕСТИРОВАНИЕ СИСТЕМЫ ГЕНЕРАЦИИ ПОСТОВ ДЛЯ TELEGRAM")
    print("" + "="*80)

    # Проверяем, что мы в правильной директории
    current_dir = os.path.dirname(os.path.abspath(__file__))
    logger.info(f"📁 Текущая директория: {current_dir}")

    # Запускаем сравнительный тест
    compare_formats()